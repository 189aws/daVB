#!/bin/bash
# 一键脚本：配置 /root/apool/upgrade_and_run.sh 为 systemd 服务，实现开机自启

# 检查是否以 root 身份运行
if [ "$(id -u)" -ne 0 ]; then
    echo "此脚本需要以 root 权限运行，请使用 sudo 或切换到 root 用户"
    exit 1
fi

# 定义变量
SCRIPT_PATH="/root/apool/upgrade_and_run.sh"
SERVICE_FILE="/etc/systemd/system/apool-upgrade.service"
LOG_FILE="/root/apool/upgrade_and_run.log"

# 检查 upgrade_and_run.sh 是否存在
if [ ! -f "$SCRIPT_PATH" ]; then
    echo "错误：$SCRIPT_PATH 不存在，请确认文件路径"
    exit 1
fi

# 确保脚本有可执行权限
chmod +x "$SCRIPT_PATH"

# 安装依赖工具
echo "检查并安装依赖工具（curl、wget、tar）..."
apt update
apt install -y curl wget tar

# 创建 systemd 服务文件
echo "创建 systemd 服务文件：$SERVICE_FILE"
cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Apool Miner Upgrade and Run Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/bin/bash $SCRIPT_PATH
Restart=always
RestartSec=10
User=root
WorkingDirectory=/root/apool
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
StandardOutput=append:$LOG_FILE
StandardError=append:$LOG_FILE

[Install]
WantedBy=multi-user.target
EOF

# 设置服务文件权限
chmod 644 "$SERVICE_FILE"

# 重新加载 systemd 配置
echo "重新加载 systemd 配置..."
systemctl daemon-reload

# 启用服务（开机自启）
echo "启用 apool-upgrade 服务..."
systemctl enable apool-upgrade.service

# 启动服务
echo "启动 apool-upgrade 服务..."
systemctl start apool-upgrade.service

# 检查服务状态
echo "检查服务状态..."
systemctl status apool-upgrade.service --no-pager -l

# 提示日志查看方式
echo -e "\n配置完成！"
echo "服务日志已重定向到 $LOG_FILE"
echo "你可以通过以下命令查看实时日志："
echo "  journalctl -u apool-upgrade.service -f"
echo "或查看脚本日志文件："
echo "  cat $LOG_FILE"
echo "如果服务未正常运行，请检查日志或确认网络连接"
